#include "user.h"


user::user(void)
{
}


user::~user(void)
{
}
