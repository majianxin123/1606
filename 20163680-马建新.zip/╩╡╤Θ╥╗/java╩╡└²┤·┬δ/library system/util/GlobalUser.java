package maylor.system.util;

import maylor.system.model.User;

public class GlobalUser {
	public static User LOGIN_USER;
}
