package maylor.system.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import maylor.system.dao.IReaderDAO;
import maylor.system.model.Reader;

/**
 * ������Ϣ�����ӿ�ʵ����
 * @author Administrator
 *
 */
public class IReaderDAOImpl implements IReaderDAO {
	private Connection conn=null;
	public IReaderDAOImpl(Connection conn){
		this.conn=conn;	
	}

	@Override
	public boolean doCreate(Reader reader) throws Exception {
		//���Ӷ�����Ϣ
		boolean flag = false;
		PreparedStatement pstmt = null;
		String sql = "INSERT INTO library_reader(id,name ,type,sex,days_num)VALUES(?,?,?,?,?)";
		try {
			pstmt = this.conn.prepareStatement(sql);
			pstmt.setString(1, reader.getId());
			pstmt.setString(2, reader.getName());
			pstmt.setString(3, reader.getType());
			pstmt.setString(4, reader.getSex());
			pstmt.setInt(5, reader.getDays_num());
			if (pstmt.executeUpdate() > 0) {
				flag = true;
			}
		} catch (Exception e) {
			throw e;
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}

			} catch (Exception e) {
			}
		}

		return flag;
	}

	@Override
	public boolean doUpdate(Reader reader) throws Exception {
		//���¶�����Ϣ
		boolean flag = false;
		PreparedStatement pstmt = null;
		String sql = "UPDATE library_reader SET name=?,type=?,sex=?,days_num=? WHERE id=?";
		try {
			pstmt = this.conn.prepareStatement(sql);
			pstmt.setString(1,reader.getName());
			pstmt.setString(2, reader.getType());
			pstmt.setString(3, reader.getSex());
			pstmt.setInt(4,reader.getDays_num());
			pstmt.setString(5, reader.getId());
			if (pstmt.executeUpdate() > 0) {
				flag = true;
			}
		} catch (Exception e) {
			throw e;
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}

			} catch (Exception e) {
			}
		}

		return flag;
	}

	@Override
	public boolean doDelete(String id) throws Exception {
		//ɾ��������Ϣ
		boolean flag = false;
		PreparedStatement pstmt = null;
		String sql = "DELETE FROM library_reader WHERE id=?";
		try {
			pstmt = this.conn.prepareStatement(sql);
			pstmt.setString(1, id);
			if (pstmt.executeUpdate() > 0) {
				flag = true;
			}
		} catch (Exception e) {
			throw e;
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}

			} catch (Exception e) {
			}
		}

		return flag;
	}

	@Override
	public Reader findById(String id) throws Exception {
		// ���Ҷ�����Ϣ-ID����
		Reader reader = null;
		PreparedStatement pstmt = null;
		String sql = "SELECT * FROM library_reader WHERE id=?";
		try {
			pstmt = this.conn.prepareStatement(sql);
			pstmt.setString(1, id);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				reader = new Reader();
				reader.setIncre_id(rs.getInt(1));
				reader.setId(rs.getString(2));
				reader.setName(rs.getString(3));
				reader.setType(rs.getString(4));
				reader.setSex(rs.getString(5));
				reader.setDays_num(rs.getInt(6));
			}
			rs.close();
		} catch (Exception e) {
			throw e;
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}

			} catch (Exception e) {
			}
		}
		return reader;
	}

	@Override
	public List<Reader> findAll(String keyword) throws Exception {
		//���Ҷ�����Ϣ-�ؼ��ֲ���
		List<Reader> all=new ArrayList<Reader>();
		PreparedStatement pstmt = null;
		String sql="SELECT incre_id,id,name,type,sex,days_num FROM library_reader WHERE id LIKE ? OR name LIKE ? OR type LIKE ? OR sex LIKE ? OR days_num LIKE ? ";
		try{
			pstmt=this.conn.prepareStatement(sql);
			pstmt.setString(1, "%"+keyword+"%");
			pstmt.setString(2, "%"+keyword+"%");
			pstmt.setString(3, "%"+keyword+"%");
			pstmt.setString(4, "%"+keyword+"%");
			pstmt.setString(5, "%"+keyword+"%");
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				Reader reader = new Reader();
				reader.setIncre_id(rs.getInt(1));
				reader.setId(rs.getString(2));
				reader.setName(rs.getString(3));
				reader.setType(rs.getString(4));
				reader.setSex(rs.getString(5));
				reader.setDays_num(rs.getInt(6));
				all.add(reader);
			}
			rs.close();
		}catch(Exception e){
		  throw e;
		}finally{
			try{
				if(pstmt!=null){
					pstmt.close();
				}
				
			}catch(Exception e){}
		}
		return all;
	}

}
