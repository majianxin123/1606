package maylor.system.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import maylor.system.dao.IBorrowDAO;
import maylor.system.model.Borrow;

/**
 * ������Ϣ�����ӿ�ʵ����
 * @author Administrator
 *
 */
public class IBorrowDAOImpl implements IBorrowDAO {
	private Connection conn = null;
	public IBorrowDAOImpl(Connection conn) {
		this.conn = conn;
	}

	@Override
	public boolean doCreate(Borrow borrow) throws Exception {
		//���ӽ�����Ϣ
		boolean flag = false;
		PreparedStatement pstmt = null;
		String sql = "INSERT INTO library_borrow(book_id,reader_id ,borrow_date,back_date,is_back)VALUES(?,?,?,?,?)";
		try {
			pstmt = this.conn.prepareStatement(sql);
			pstmt.setString(1, borrow.getBook_id());
			pstmt.setString(2, borrow.getReader_id());
			pstmt.setDate(3, new java.sql.Date(borrow.getBorrow_date()
					.getTime()));
			pstmt.setDate(4, new java.sql.Date(borrow.getBack_date().getTime()));
			pstmt.setInt(5, borrow.getIs_back());
			if (pstmt.executeUpdate() > 0) {
				flag = true;
			}
		} catch (Exception e) {
			throw e;
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}

			} catch (Exception e) {
			}
		}

		return flag;
	}

	@Override
	public boolean doUpdate(Borrow borrow) throws Exception {
		//���½�����Ϣ
		boolean flag = false;
		PreparedStatement pstmt = null;
		String sql = "UPDATE library_borrow SET book_id=?,borrow_date=?,back_date=?,is_back=? WHERE reader_id=?";
		try {
			pstmt = this.conn.prepareStatement(sql);
			pstmt.setString(1, borrow.getBook_id());
			pstmt.setDate(2, new java.sql.Date(borrow.getBorrow_date().getTime()));
			pstmt.setDate(3, new java.sql.Date(borrow.getBack_date().getTime()));
			pstmt.setInt(4, borrow.getIs_back());
			pstmt.setString(5, borrow.getReader_id());
			if (pstmt.executeUpdate() > 0) {
				flag = true;
			}
		} catch (Exception e) {
			throw e;
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}

			} catch (Exception e) {
			}
		}

		return flag;
	}

	@Override
	public boolean doDelete(int id) throws Exception {
		//ɾ��������Ϣ
		boolean flag = false;
		PreparedStatement pstmt = null;
		String sql = "DELETE FROM library_borrow WHERE id=?";
		try {
			pstmt = this.conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			if (pstmt.executeUpdate() > 0) {
				flag = true;
			}
		} catch (Exception e) {
			throw e;
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}

			} catch (Exception e) {
			}
		}

		return flag;
	}

	@Override
	public Borrow findById(String id) throws Exception {
		// ���ҽ�����Ϣ-ID����
		Borrow borrow = null;
		PreparedStatement pstmt = null;
		String sql = "SELECT * FROM library_borrow WHERE reader_id=?";
		try {
			pstmt = this.conn.prepareStatement(sql);
			pstmt.setString(1, id);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				borrow = new Borrow();
				borrow.setId(rs.getInt(1));
				borrow.setReader_id(rs.getString(2));
				borrow.setBook_id(rs.getString(3));
				borrow.setBorrow_date(rs.getDate(4));
				borrow.setBack_date(rs.getDate(5));
				borrow.setIs_back(rs.getInt(6));
			}
			rs.close();
		} catch (Exception e) {
			throw e;
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}

			} catch (Exception e) {
			}
		}
		return borrow;
	}
	

	@Override
	public Borrow findById(int id) throws Exception {
		// ���ҽ�����Ϣ-ID����
		Borrow borrow = null;
		PreparedStatement pstmt = null;
		String sql = "SELECT * FROM library_borrow WHERE id=?";
		try {
			pstmt = this.conn.prepareStatement(sql);
			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				borrow = new Borrow();
				borrow.setId(rs.getInt(1));
				borrow.setReader_id(rs.getString(2));
				borrow.setBook_id(rs.getString(3));
				borrow.setBorrow_date(rs.getDate(4));
				borrow.setBack_date(rs.getDate(5));
				borrow.setIs_back(rs.getInt(6));
			}
			rs.close();
		} catch (Exception e) {
			throw e;
		} finally {
			try {
				if (pstmt != null) {
					pstmt.close();
				}

			} catch (Exception e) {
			}
		}
		return borrow;
	}

	@Override
	public List<Borrow> findAll(String keyword) throws Exception {
		//���ҽ�����Ϣ-�ؼ��ֲ���
		List<Borrow> all=new ArrayList<Borrow>();
		PreparedStatement pstmt = null;
		String sql="SELECT id,reader_id,book_id,borrow_date,back_date,is_back FROM library_borrow WHERE reader_id LIKE ? OR book_id LIKE ? OR borrow_date LIKE ? OR back_date LIKE ? OR is_back LIKE ?";
		try{
			pstmt=this.conn.prepareStatement(sql);
			pstmt.setString(1, "%"+keyword+"%");
			pstmt.setString(2, "%"+keyword+"%");
			pstmt.setString(3, "%"+keyword+"%");
			pstmt.setString(4, "%"+keyword+"%");
			pstmt.setString(5, "%"+keyword+"%");
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				Borrow borrow = new Borrow();
				borrow.setId(rs.getInt(1));
				borrow.setReader_id(rs.getString(2));
				borrow.setBook_id(rs.getString(3));
				borrow.setBorrow_date(rs.getDate(4));
				borrow.setBack_date(rs.getDate(5));
				borrow.setIs_back(rs.getInt(6));
				all.add(borrow);
			}
			rs.close();
		}catch(Exception e){
		  throw e;
		}finally{
			try{
				if(pstmt!=null){
					pstmt.close();
				}
				
			}catch(Exception e){}
		}
		return all;
	}

}
